'''
Created on 17-Jun-2017

@author: BALASUBRAMANIAM
'''
#list of tuples
scores=([6,7,8],[8,9,5],[9,7,5])

scores[0].append(9)
print(scores)