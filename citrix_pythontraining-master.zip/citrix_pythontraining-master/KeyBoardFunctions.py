'''
Created on 21-Aug-2017

@author: BALASUBRAMANIAM
'''
import pyautogui
#caps lock toggle
pyautogui.press('capslock')
#open task manager
pyautogui.hotkey('ctrl','shift','esc')
