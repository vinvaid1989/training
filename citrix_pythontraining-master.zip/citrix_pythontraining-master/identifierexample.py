#Identifiers explained
'''
Author:Parameswari
Date:23 Nov 2017
'''
org_name="citrix"
location="bangalore"
message="Profit for the quarter is increased\
         by 35%"

print("Organization Name=\t%s\n Location=%s\n" %(org_name,location))
#print("Location=",location)